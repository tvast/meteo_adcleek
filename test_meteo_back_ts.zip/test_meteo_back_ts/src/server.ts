import { Database } from "./helper/Database";
import { InitDb } from "./setup/InitDb";

// pour permettre la communication entre le front et le back en dev.
//import cors from 'cors';

// a ajouter pour la communication entre le front et le back en dev lorsque express est instancié
/*app.use(cors({
  credentials: true
}));*/

async function launch() {
  try {
    // Code à garder pour intialiser la base de données
    const database = new Database(":memory:");
    const initDb = new InitDb(database);
    await initDb.initialize();
    // Fin du code à garder.

    // exemple de code pour utiliser la base de données
    const all = await database.all("select * from city");
    console.table(all);
  } catch (error) {
    console.log(error);
  }
}

launch();
